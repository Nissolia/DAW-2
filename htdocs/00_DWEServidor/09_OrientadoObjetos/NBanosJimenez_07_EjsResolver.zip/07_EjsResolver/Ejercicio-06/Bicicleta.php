<?php
include_once 'Vehiculo.php';
class Bicicleta extends Vehiculo
{
    //hacer el caballito
    public function hacerCaballito()
    {
        return "¡Estoy haciendo el caballito con la bicicleta!";
    }

}
